let Person = require('./person.js');
//The following is only for JUDGE System submitting.
result.Person = Person;